<div class="chatarea"><div style="height: 30px;"></div></div>
<div class="inputarea">
    <input type="text" id="msg" onkeyup="keyUpChat(this, event)" autofocus />
</div>
<script type="text/javascript">startChat();</script>