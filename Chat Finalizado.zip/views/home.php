<div class='imghome'>
    <a  href="/cliente"><img class='imgclientesuporte' src="assets/images/cliente.png" title="Cliente" alt="Area do Cliente" ></a>
    <a  href="/suporte"><img class='imgclientesuporte' src="assets/images/suporte.png" title="Suporte" alt="Suporte Especializado"></a>
</div>