<form method="POST" style="text-align:center">
	Qual seu nome?<br/><br/>
	
        <input type="text" name="nome" autofocus /><br/><br/>

	<input type="submit" value="Entrar no Chat" />
</form>