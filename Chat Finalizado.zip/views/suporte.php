<h1>Área de Chamados</h1>

<table border="0" width="100%" id="areadechamados">
	<tr>
		<th width="80">Data/Hora</th>
		<th>Nome do Cliente</th>
		<th width="150">Ações</th>
	</tr>
</table>
<script type="text/javascript">
iniciarSuporte();
</script>